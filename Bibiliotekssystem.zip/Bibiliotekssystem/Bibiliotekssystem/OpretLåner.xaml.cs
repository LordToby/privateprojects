﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bibiliotekssystem.DAL;
using Bibiliotekssystem.Model;

namespace Bibiliotekssystem
{
    /// <summary>
    /// Interaction logic for OpretLåner.xaml
    /// </summary>
    public partial class OpretLåner : Window
    {

        private Database context = Database.Instance;
        public OpretLåner()
        {
            InitializeComponent();
        }

        private void Godkend_Click(object sender, RoutedEventArgs e)
        {
            if(NavnOpret.Text == "" || LånerKortOpret.Text == "")
            {
                MessageBox.Show("Der mangler udfyldte værdier!");
            }
            else
            {
                //Skal man måske slette vinduet fra hukommelsen igen, når man er færdig
                context.Lånere.Add(new Låner(NavnOpret.Text, LånerKortOpret.Text));
                context.SaveChanges();
                this.Close();
            }
            
        }
    }
}
