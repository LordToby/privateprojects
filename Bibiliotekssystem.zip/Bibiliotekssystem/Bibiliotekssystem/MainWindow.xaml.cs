﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using Bibiliotekssystem.DAL;
using Bibiliotekssystem.Model;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using Database = Bibiliotekssystem.DAL.Database;

namespace Bibiliotekssystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Instans af databasen.
        private Database context = Database.Instance;
        public MainWindow()
        {
            InitializeComponent();           
            SearchButton.Background = Brushes.DarkGray;  //Da det var besværligt at sætte hexadecimal værdien i koden for hvornår musen kører henover en knap sætter jeg defalt værdien her
            //Listen skal være udfyldt fra starten, hvorfor jeg kalder en hjælpemetode.
            VisAlt(); 
        }


        //Hjælpemetode til at initialisere data fra databasen.
        private void VisAlt()
        {
            
            QueryableExtensions.Load(context.Materialer);
            MaterialeListe.ItemsSource = context.Materialer.Local.Where(m=> m.Kopi > 0).OrderBy(m=> m.Title);
            LånerListe.ItemsSource = context.Lånere.Local; //Binder til lokale version af databasen.
           
        }

        //Eksekveres hver gang man åbner fanen for aflevering´.
        private void Init_Afleverinspane(object sender, RoutedEventArgs e)
        {
            AfleverinsListe.Items.Clear();
            QueryableExtensions.Load(context.Lånere);
            Låners.ItemsSource = context.Lånere.Local;
        }

        //Til afleverings-fanen
        private void Vis_Låners_Materialer(object sender, RoutedEventArgs e)
        {
            Låner l = Låners.SelectedItem as Låner;
            AfleverinsListe.Items.Clear();
            foreach (Materiale m in l.UdlånteMaterialer)
            {
                AfleverinsListe.Items.Add(m);
            }
        }

        //Til afleverings-fanen
        private void Aflevér(object sender, RoutedEventArgs e)
        {
            List<Materiale> afleveringsliste = new List<Materiale>();
            if(AfleverinsListe.Items.Count > 0)
            {
                foreach(Materiale m in AfleverinsListe.Items)
                {
                    afleveringsliste.Add(m);
                    m.Låner.UdlånteMaterialer.Remove(m); //Fjerner sig selv fra Låner.
                    m.Kopi++; //Kommer tilbage i listen.
                    m.Låner = null; //Fjerner relationen.
                    m.UdlånsDato = null; //Materialet er ikke længere udlånt.
                    context.SaveChanges();
                }
                string afleveret = string.Join(",\n", afleveringsliste);
                MessageBox.Show("Der er aflveret følgende materialer: \n \n" + afleveret);
                AfleverinsListe.Items.Clear();
            }
        }

        private void Opret_Materiale_Click(object sender, RoutedEventArgs e)
        {
            OpretLåner opretLåner = new OpretLåner();
            opretLåner.Show();
        }

        private void MaterialeListe_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Materiale m = MaterialeListe.SelectedItem as Materiale;
            if (m != null)
            {
                DetaljeVindue.Text = m.Detalje;
            }

        }


        private void Tilføj_til_kurv(object sender, RoutedEventArgs e)
        {
            
            Materiale m = MaterialeListe.SelectedItem as Materiale; 
            //Sørger for at ét materiale er valgt, og at der kopier af materialet til rådighed.
            if(m != null && m.Kopi > 0)
            {
                m.Kopi--;
                Kurv.Items.Add(m);
            }
            else
            {
                if(m== null)
                {
                    MessageBox.Show("Der er ikke valgt en låner");
                }
                else if(m.Kopi <= 0)
                {
                    MessageBox.Show("Der er ikke flere eksemplarer til rådighed");
                }
            }
        }

        private void Lån_Materiale_Click(object sender, RoutedEventArgs e)
        {
            Låner l = LånerListe.SelectedItem as Låner; 
            if(l != null)
            {
                foreach (Materiale materiale in Kurv.Items)
                {
                    materiale.UdlånsDato = DateTime.Now;
                    materiale.Låner = l;
                    l.UdlånteMaterialer.Add(materiale);
                    context.SaveChanges();
                    MessageBox.Show($"{l.Name} foretog et Lån!");
                   
                }
            }
            else
            {
                MessageBox.Show("Ingen låner er valgt");
            }
            Kurv.Items.Clear();

        }
        private void Søg_Materialer(object sender, RoutedEventArgs e)
        {

            if (SearchBox.Text.Length > 0) //Havde vi ikke dette tjek, ville alle elementer i listen blive ryddet.
            {
                var fundet = context.Materialer.Local.Where(m => m.Title == SearchBox.Text || m.Forfatter == SearchBox.Text);
                SearchButton.Background = Brushes.Black;
                MaterialeListe.ItemsSource = fundet;
            }
            else
            {
                var fundet = context.Materialer.Local;
                SearchButton.Background = Brushes.Black;
                MaterialeListe.ItemsSource = fundet;
            }

        }

        //Denne metode samler alle radiobuttons under et grid jeg kalder for RadioGroup og checker på dens subelementer 'Children'
        private void Check_Condtion(object sender, RoutedEventArgs e)
        {
            
            if(RadioGroup.Children.IndexOf(Bogcheck) == 0 && Bogcheck.IsChecked == true)
            {

                var query = context.Materialer.Local.Where(f => f.MaterialeType == EnumMaterialeType.Bog);
                MaterialeListe.ItemsSource = query;

            }
            else if(RadioGroup.Children.IndexOf(SpilCheck) == 1 && SpilCheck.IsChecked == true)
            {

                var query = context.Materialer.Local.Where(f => f.MaterialeType == EnumMaterialeType.Spil);
                MaterialeListe.ItemsSource = query;
                               
            }
            else if (RadioGroup.Children.IndexOf(MusikCheck) == 2 && MusikCheck.IsChecked == true)
            {

                var query = context.Materialer.Local.Where(f => f.MaterialeType == EnumMaterialeType.Musik);
                MaterialeListe.ItemsSource = query;
            
            }
            else if (RadioGroup.Children.IndexOf(FilmCheck) == 3 && FilmCheck.IsChecked == true)
            {

                var query = context.Materialer.Local.Where(f => f.MaterialeType == EnumMaterialeType.Film);
                MaterialeListe.ItemsSource= query;
            }

            else
            {
                VisAlt();
            }
        }

        private void Fjern_Item(object sender, RoutedEventArgs e)
        {
            Materiale m = Kurv.SelectedItem as Materiale;

            if(m != null)
            {
                m.Kopi++;
                Kurv.Items.Remove(m);
            }
        }

        private void Turn_Dark(object sender, MouseEventArgs e)
        {
            SearchButton.Background = Brushes.Gray;
        }

        private void Turn_Light(object sender, MouseEventArgs e)
        {
            SearchButton.Background = Brushes.DarkGray;
        }

  

    }
}
