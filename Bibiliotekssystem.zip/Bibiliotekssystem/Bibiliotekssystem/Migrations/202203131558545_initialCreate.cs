﻿namespace Bibiliotekssystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Låner",
                c => new
                    {
                        LånerID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        LånerKort = c.String(),
                    })
                .PrimaryKey(t => t.LånerID);
            
            CreateTable(
                "dbo.Materiale",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        ISBN = c.String(),
                        UdlånsDato = c.DateTime(),
                        Beskrivelse = c.String(),
                        Forfatter = c.String(),
                        MaterialeType = c.Int(nullable: false),
                        Kopi = c.Int(nullable: false),
                        Låner_LånerID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Låner", t => t.Låner_LånerID)
                .Index(t => t.Låner_LånerID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Materiale", "Låner_LånerID", "dbo.Låner");
            DropIndex("dbo.Materiale", new[] { "Låner_LånerID" });
            DropTable("dbo.Materiale");
            DropTable("dbo.Låner");
        }
    }
}
