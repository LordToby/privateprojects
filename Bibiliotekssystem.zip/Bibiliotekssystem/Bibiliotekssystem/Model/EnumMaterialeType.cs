﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibiliotekssystem.Model
{
    public enum EnumMaterialeType
    {
        Bog,
        Spil,
        Film,
        Musik

    }
}
