﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Threading.Tasks;

namespace Bibiliotekssystem.Model
{
    public class Materiale:INotifyPropertyChanged
    {
        //Metoder til at kunne håndtere databinding. 
        public event PropertyChangedEventHandler PropertyChanged; //Der er brug for denne variabel for at vi kan lave nedenstående metode.

        private void NotifPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public int ID { get; set; } //Unikke primary key
        public string Title { get; set; }

        public string ISBN { get; set; }

        public DateTime? UdlånsDato { get; set; } //Skal være null, hvis den ikke er udlånt.

        public string Beskrivelse { get; set; } 

        public string Forfatter { get; set; }

        private int _kopi;

        public EnumMaterialeType MaterialeType { get; set; }

        public Låner Låner { get; set; } //Fungerer som foreign key over til Låner.


        //Sætter databinding, således at ændringer i programkoden reflekteres i GUI'en
        public int Kopi
        {
            get => _kopi;
            set
            {
                _kopi = value;
                NotifPropertyChanged("Kopi");
            }
        }
        public Materiale()
        {

        }

        public Materiale(string title, string isbn, DateTime? udlånsdato, string beskrivelse, string forfatter, EnumMaterialeType et, int kopi)
        {
            Title = title;
            ISBN = isbn;
            UdlånsDato = udlånsdato;
            Beskrivelse = beskrivelse;
            Forfatter = forfatter;
            MaterialeType = et;
            _kopi = kopi; //Dette er den eneste variabel, jeg har brug for at sætte databinding på, hvorfor jeg hér benytter mig af den private attribut istedet for propertien
        }

        //Vises ved listen over de materialer, man kan låne.
        public string Info
        {          
            get { return $"{Forfatter}: \n {Title}, \n Antal: {Kopi} \n"; }
        }

        //Vises, når man er ved at aflevere sine lånte materialer på fanen for aflvering
        public string AfleveringsInfo
        {
            get { return $"{Forfatter} \n {Title} \n {UdlånsDato} \n Materiale:{MaterialeType}"; }
        }

        //Vises når et materiale er i listen over, det man vil låne.
        public string LåneInfo
        {
            get { return $"{Forfatter} \n {Title} \n Materiale: {MaterialeType} "; }

        }

        //Vises når man vil se detaljer om et materiale.
        public string Detalje
        {
            get { return $"Tittel: {Title} \n ISBN: {ISBN}, \n Beskrivelse: {Beskrivelse}, \n Forfatter: {Forfatter}, \n Materiale: {MaterialeType} "; }
        }

        //Bruges når MessageBox.show kaldes på et Materiale objekt.
        public override string ToString()
        {
            return $"Tittel: {Title} \n ISBN: {ISBN}, \n Forfatter: {Forfatter}, \n Materiale: {MaterialeType} ";
        }

    }
}
