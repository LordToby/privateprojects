﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibiliotekssystem.Model
{
    public class Låner
    {
        private List<Materiale> materialer = new List<Materiale>();
        public string Name { get; set; }
        public string LånerKort { get; set; }
        public int LånerID { get; set; } //primary key for en låner.
        public virtual List<Materiale> UdlånteMaterialer { get
            {
                return materialer;
            } 
        }
        public Låner()
        {

        }

        public Låner(string name, string lånerKort)
        {
            Name = name;
            LånerKort = lånerKort;
        }

        //Metoden bruges til at vise informationer om en Låner i GUI'en.
        public string Info
        {
            get { return Name + "\n" + LånerKort; }
        }

        
    }
}
