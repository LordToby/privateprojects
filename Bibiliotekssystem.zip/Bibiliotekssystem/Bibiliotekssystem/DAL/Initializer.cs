﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bibiliotekssystem.Model;
using System.Data.Entity;

namespace Bibiliotekssystem.DAL
{
    internal class Initializer : CreateDatabaseIfNotExists<Database>
    {
        /*Første gang databasen oprettes, får vi oprettet nedenstående objekter, som så tilføjes til databasen, 
         * som vi derefter kan hente fra i programkoden.     
        */
        protected override void Seed(Database context)
        {      
            //Bøger. 
            Materiale bog1 = new Materiale("Den Grimme Ælling", "978-87-552-3333-1", null, "Fortællingen om en udstødt ælling der endte med at blive en smuk svane", "H.C Andersen", EnumMaterialeType.Bog, 3);
            Materiale bog2 = new Materiale("Harry Potter og de vises sten", "978-87-422-3353-2", null, "En dreng som opdager, at han har magiske evner", "J.K. Rowling", EnumMaterialeType.Bog, 5);
            Materiale bog3 = new Materiale("Factfullness", "978-87-332-1223-1", null, "Faglitteratur om, hvordan man gennem fakta anskuer verden", "Hans Rosling", EnumMaterialeType.Bog, 4);
            //Spil
            Materiale spil1 = new Materiale("The Legend Of Zelda", "978-87-532-1141-4", null, "Styr helten Link genenm en eventyrlig verden og red den fra den onde Ganon", "Nintendo", EnumMaterialeType.Spil, 2);
            Materiale spil2 = new Materiale("Red Dead Redemption 2", "978-87-252-4232-3", null, "I det vilde vesten styrer du en sherif, der involveres i forskellige sager", "Rockstar Games", EnumMaterialeType.Spil, 7);
            //Musik
            Materiale musik1 = new Materiale("Shubidua greatest hits", "978-87-311-3424-2", null, "De største hits fra Shubidua de seneste 40 år", "Pladefirma Inc", EnumMaterialeType.Musik, 1);
            //Film
            Materiale film1 = new Materiale("Life of Brian", "978-87-245-1954-3", null, "En historie om en mand, der levede på samme tid som Jesus og involveres i en jødisk oprørsgruppe mod romerne", "Monty Python", EnumMaterialeType.Film, 2);
            Materiale film2 = new Materiale("Find Nemo", "978-87-411-4219-9", null, "En fisks søn bliver bortfør og han må nu rejse gennem den undersøiske verden for at rede ham", "Disney Pixar", EnumMaterialeType.Film, 2);

            context.Materialer.Add(bog1);
            context.Materialer.Add(bog2);
            context.Materialer.Add(bog3);
            context.Materialer.Add(spil1);
            context.Materialer.Add(spil2);
            context.Materialer.Add(musik1);
            context.Materialer.Add(film1);
            context.Materialer.Add(film2);
            context.SaveChanges();
        }
    }
}
