﻿using Bibiliotekssystem.Model; //Namespace anvendt for at jeg kan tilgå model-mappen
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Bibiliotekssystem.DAL
{
    public class Database: DbContext
    {
        //Singleton for at lave database, der kun kan oprettes én gang

        private static Database instance = null;
         
        //Vi har dog stadig brug for en public constructor, for at migration-koden kan forstå hvorhenne den skaber forbindelsen
        private Database(): base("Materialer")
        {

        }

        public static Database Instance
        {
            get
            {
                if(instance == null)
                {
                    instance = new Database();
                }
                return instance;
            }
        }

        //Fortæller databasen, at den ikke skal skrive tabellerne i flertal.
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        public DbSet<Materiale> Materialer { get; set; }
        public DbSet<Låner> Lånere { get; set; }

    }
}
