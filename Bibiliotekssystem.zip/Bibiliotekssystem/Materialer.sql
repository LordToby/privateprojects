
Select * from Materiale

Select * from L�ner

delete from Materiale

delete from L�ner

drop database Materialer1

