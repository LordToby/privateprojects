

let sentences = ["Jakob læser i en lang bog",
"Det er sundt at gå tidligt i seng",
"Der er mange penge at spare, ved at skrue ned for varmen",
"Han løber en tur en kold morgen",
"En god kop kaffe er altid godt",
"Midas fra Fortnite er sej",
"Jakob læste i en lang bog",
"Vi så en ræv på vej hjem",
"De spiste altid sent på hverdage",
"Jeg byggede et fly helt selv"

,
];
let i = 0;
let hints = 0;

let textShow = document.querySelector('.text-show');
let score = 0;

let hintsText = document.querySelector(".hints");

let textField = document.querySelector(".text-field")

let button = document.querySelector(".myButton");

let correctAnswer = document.getElementById("correctAnswer")

let wrongAnswer = document.getElementById("wrongAnswer")

let result = document.getElementById("result");

let completionArea = document.getElementById("completion")

let retryButton = document.querySelector(".retry")

let scoreText = document.querySelector(".score");

let hintButton = document.querySelector(".hintButton")



button.addEventListener('click', function(){
 
    let text = textField.value.trim();
    console.log(text);
    console.log(sentences[i])
    if(text != null){
        if(text.toLowerCase() == sentences[i].toLowerCase()){
                 
            showAnswers(text, true)
        }
        else{
            showAnswers(text, false);
        }
    }
})

hintButton.addEventListener("click", function(){
    if(hints > 0){
        hintButton.disabled = true;
        button.disabled = true;
        textField.disabled = true;
        showSentence();
        hints--;
        hintsText.innerHTML = hints;
    }
})

retryButton.addEventListener('click', ()=>{
startGame();
})




function showAnswers(yourAnswer, correct){
    button.disabled = true;
    textField.disabled = true;
    hintButton.disabled = true;
    if(!correct){
        wrongAnswer.textContent = "Forkert! Du svarede: \n" + yourAnswer;
        correctAnswer.textContent = "Det rigtige svar var: \n" + sentences[i];
    }
    else{
        score++;
        correctAnswer.textContent = "Du svarede rigtigt!"
        scoreText.innerHTML = score;
    }

    setTimeout(() => {
         i++;
        textField.value = "";
        hints = 2;
        hintsText.innerHTML = hints;     
        showSentence();
    }, 4000)

}

function showSentence(){
   
    if(i === sentences.length){
        showResults();
    }
    else{
    correctAnswer.innerHTML = "";
    wrongAnswer.innerHTML = "";
    textShow.style.visibility = "visible";
    textShow.innerHTML = sentences[i];
    setTimeout(() => {
        textField.disabled = false;
        button.disabled = false;
        hintButton.disabled = false;
        hideSentence()
    }, 4000);
   }
}

function hideSentence(){
    console.log("called by timeout");
    textShow.style.visibility = "hidden";
}

function startGame(){
    i = 0;
    score = 0;
    scoreText.innerHTML = score;
    hints = 2;
    hintsText.innerHTML = hints;
    button.disabled = true;
    textField.disabled = true;
    hintButton.disabled = true;
    completionArea.style.visibility = "hidden";
    showSentence();
}


function showResults(){
    textShow.innerHTML = "";
    correctAnswer.innerHTML = "";
    wrongAnswer.innerHTML = "";
    completionArea.style.visibility = "visible";
    result.textContent = `Spillet er slut. Du fik ${score} ud af ${sentences.length} mulige point`
}

startGame();