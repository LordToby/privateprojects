import random

#Delopgave b i GA

originalString = "to be or not to be that is the question";

#Streng af alfabetet, som vi bruger til at lave tilfældige strenge med
alphabet = "abcdefghijklmnopqrstuvxyz "

#Her har vi konverteret strengen til en liste
chars = list(alphabet)

#Laver liste af tilfældigt genereret strenge
def generateRandomStrings(amount):
    #Tom liste af strings
    localRandomStrings = []

    for i in range(amount):
        newstring = ""
        for j in range(len(originalString)):
            newstring += chars[random.randint(0, len(chars)-1)]
        localRandomStrings.append(newstring)
    return localRandomStrings



def checkFitness(string):
    counter = 0
    i = 0
    if(len(string) == len(originalString)):
        for char in string:
            if(char == originalString[i].lower()):
                counter +=1
            i += 1
    return counter

#Her eksekverer vi koden for checkfitness

randomStrings = generateRandomStrings(10000)


counters = []
for string in randomStrings:
    counters.append(checkFitness(string))

print("Højeste tal i talArrayet", max(counters))

#Finder de 10 procent af strengene med den højeste fitness og gemmer i et array af dictionaries
def getPopulationPercent(population):
    arrWithFitness = []
    for s in population:
        fit = checkFitness(s)
        arrWithFitness.append({"sentence": s, "fitness": fit}) #Gemmer værdien i et dictionary med bogstaverne som key og
    arrWithFitness.sort(key=lambda sent: sent["fitness"], reverse=True)
    theTenPercent = []
    x = 0
    while x < (len(population) /10):
        theTenPercent.append(arrWithFitness[x])
        x+=1
    return theTenPercent

myPopulation = generateRandomStrings(10000)

best10 = getPopulationPercent(myPopulation)

#Her får vi de 10 bedste
print(best10)

#Laver et lille mellemrum i programmet, for at gøre det mere overskueligt at læse udførslen
print("")
#---------------------------------------------------------------

#Opgave 3.C

#Hill climbing

#Laver ny population
population2 = generateRandomStrings(100)

randString = population2[random.randint(0, len(population2)-1)]

randStringIndx = population2.index(randString) #Den index plads, hvopå den tilfældige string ligger


#Har lavet to implementationer af hill climbing. I den første anvender jeg rekursion til at finde strengen med den højeste værdi

#Virker med 1000 og med 1000 strings men ikke med 10000, hvor den bliver ved med at fortsætte

def theBestString(string, index, population):

    bestString = string

    currentFit = checkFitness(bestString)

    neighbourFit = checkFitness(population[index])

    #Termineringsregel: Vi stopper søgningen, hvis input index er 0 eller lig længden på populationen
    if index == 0 or index == len(population):
        print("Nu skulle vi slutte")
        print("Den bedste fitness lå på ", currentFit)
        return bestString

    print("Vi fortsætter søgningen")
    print("Bedste fit hidtil er", currentFit)
    if(neighbourFit > currentFit):
        bestString = population[index]
        return theBestString(bestString, index +1, population)
    else:
        return theBestString(bestString, index -1, population)


#Min anden implementation af hill climbing, hvor det hele sker iterativt.
def theBestString2(string, index, population):


    beststring = string
    currentFit = checkFitness(beststring) #Fitness for den nuværende string

    while(index > 0 or index < len(population)):

        neigbourLeftFit = checkFitness(population[index - 1])
        neigbourRightFit = checkFitness(population[index + 1])
        print("Vi fortsætter med index", index)
        if(neigbourRightFit > currentFit):
           currentFit = neigbourRightFit
           beststring = population[index+1]
           index +=1
        elif(neigbourLeftFit > currentFit):
           currentFit = neigbourLeftFit
           beststring = population[index-1]
           index -=1
        else:
            print("Break kommer")
            break
    print("Højeste fit blev", currentFit)
    return beststring
#---------------------------------------

#Opgave 2. D. Genetisk algoritme implementaion

#Vi har to strenge, som er udvalgte forældre til at give halvdelen af deres tegn videre til barnet, der således kommer med i næste generation
def crossOverOperation(str1, str2):
    child = ""
    i = 0
    while i < (len(str1) / 2):
        child += str1[i]
        i+=1

    j = int(len(str2) / 2)
    while j < len(str2):
        child += str2[j]
        j+=1
    return child


#Mutererer en enkelt streng ud fra et tilfældigt tal
def stringMutation(str):
    randomNumber = random.randint(0, len(str) - 1)
    newStr = ""
    i = 0
    #Hvis i er lig randomNumber, så tiføjer vi bogstaver fra vores array af tegn. Ellers tilføjer vi blot de samme bogstaver fra vores oprindelige streng
    while i < len(str) - 1:
        if(i == randomNumber):
            newStr += chars[random.randint(0, len(chars) - 1)]
            i+=1
        else:
            newStr += str[i]
            i+=1
    return newStr

#Beregner den samlede sum af alle fitness værdier i dictionariet
def fitnessForDictionary(dict):
    sum = 0
    for fit in dict:
        sum += fit["fitness"]
    return sum

#Sammenligner to generationer finder ud af, hvilken af de to, der er størst
def compareFitness(oldGen, newGen):
    oldGenFitness = fitnessForDictionary(oldGen)
    newGenFitness = fitnessForDictionary(newGen)
    return newGenFitness > oldGenFitness


'''Nedenstående metode forsøger at implementerer en fuld genetisk algoritme indeholdende 
Både cross-over operation og mutation og optælling af nye generationer 
'''
def shakeSpereanMonkeyGA(populationsSize, generationAmount):
    generation = 1
    strings = generateRandomStrings(populationsSize)
    bestTenPercent = getPopulationPercent(strings)
    for x in range(generationAmount):
        i = 0
        while i < (populationsSize / len(bestTenPercent)):
            strings[i] = crossOverOperation(makeRandom(bestTenPercent), makeRandom(bestTenPercent))
            if(i % 5 == 0):
                strings[i] = stringMutation(strings[i])
            i+=1
        tenPercentForNewGeneration = getPopulationPercent(strings)
        if(compareFitness(bestTenPercent,tenPercentForNewGeneration)):
            bestTenPercent = tenPercentForNewGeneration
            print("Nye generation er bedre! Generation: ", generation)
            print("Fitness for de 10% bedste er nu: ", fitnessForDictionary(bestTenPercent))
        generation += 1 #Går videre til næste generation
        print("New generation is done.")

#Tager tilfældigt element fra listen af dictionaries med strenge
def makeRandom(collection):
    randomFromCollection = collection[random.randint(0, len(collection)-1)]
    newString = randomFromCollection["sentence"]
    return newString


shakeSpereanMonkeyGA(10000, 5000)