//
//  PersonalBankingApp.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI
import Firebase

@main
struct PersonalBankingApp: App {
    
    @StateObject private var appState = AppstateController()
    
    init(){
        print("Database startet!")
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(appState)
           // ContentView()
        }
    }
}


