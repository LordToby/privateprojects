//
//  ContentView.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var appstateController: AppstateController
    
    
    //Computed property af array fra appstateControlleren!
    var displayedAccounts: [Account]{
        appstateController.accounts.sorted{
            $0.name<$1.name
        }
    }
    
    var body: some View {
        NavigationView{
            List{
                ForEach(displayedAccounts) {account in                    
                    NavigationLink(destination: AccountDetail(account: account)){
                        AccountRow(account: account) //Kalder hjælpe GUI klasse med account på sig
                }
            }
            
                }
            .navigationTitle("Accounts")
            .toolbar{
                ToolbarItem(placement: .bottomBar) {
                    Spacer()
                }
                ToolbarItem(placement: .bottomBar){
                    NavigationLink{
                       AddAccount()
                    } label: {
                        Text("Add new account!")
                        Image(systemName: "plus.circle.fill")
                    }
            }
        }
        
    }
}
    
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
