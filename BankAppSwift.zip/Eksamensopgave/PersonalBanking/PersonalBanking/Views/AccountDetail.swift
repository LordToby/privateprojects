//
//  AccountDetail.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI

struct AccountDetail: View {
    

    var account: Account
    
    
    var body: some View {
        Text(account.name).font(.title)
        NavigationView{
           
            List{
                ForEach(account.transactions) {currentTransaction in
                    HStack(alignment: .top){
                        
                        VStack{
                            Text("\(currentTransaction.beneficiary)").font(.headline)
                            Text(currentTransaction.date.formatted(date: .long, time: .omitted)).font(.subheadline)
                        }
                        Spacer()
                        //Grøn og + foran ved indsættelse. Rød og - ved hævning
                        if(currentTransaction.isWithdrawal){
                            Text("-" + currentTransaction.transactionAmount.formatted(.currency(code:"kr."))).foregroundColor(.red)
                        }
                        else{
                            Text("+" + currentTransaction.transactionAmount.formatted(.currency(code:"kr."))).foregroundColor(.green)
                        }
                       
                        
                    }
                }
            }
            .navigationBarTitle("Transactions")
                
            
            .toolbar{
                ToolbarItem(placement: .navigationBarLeading){
                    NavigationLink{
                        MakeTransaction(account: account)
                    } label: {
                        Text("Make transaction")
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
        }
    }
}

//struct AccountDetail_Previews: PreviewProvider {
//    static var previews: some View {
//        AccountDetail()
//    }
//}
