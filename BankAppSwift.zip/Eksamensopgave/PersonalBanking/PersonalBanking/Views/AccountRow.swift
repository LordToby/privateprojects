//
//  AccountRow.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI

struct AccountRow: View {
    
    //Forbindelse over til modelklassel
    let account: Account
    
    var body: some View {
        HStack (alignment: .top){
            VStack (alignment: .leading, spacing: 3.0){
                Text(account.name).font(.headline)
                Text(account.kind.rawValue).font(.subheadline).foregroundColor(.gray)
                Text(account.iban).font(.subheadline).foregroundColor(.gray)
            }
            Spacer()
            Text(account.balance.formatted(.currency(code: "kr.")))
        }
    }
}

//struct AccountRow_Previews: PreviewProvider {
//    static var previews: some View {
//        AccountRow()
//    }
//}
