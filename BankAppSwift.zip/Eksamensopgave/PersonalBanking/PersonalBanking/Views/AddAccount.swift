//
//  AddAccount.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI

struct AddAccount: View {
    
    
    @Environment(\.dismiss) var dismiss // sørger for at lukke vinduet når vi er færdiges
    
    @EnvironmentObject var appstateController: AppstateController
    
    @State private var name = ""
    @State private var iban = ""
    @State private var selectedKind = Account.Kind.savings
    @State private var labelName = ""
    
    

    var body: some View {
        Form {
                TextField("Name for account", text: $name)
                .keyboardType(.alphabet)
                    TextField("Iban number", text: $iban)
                .keyboardType(.alphabet)
                
            Picker("Category", selection: $selectedKind){
                ForEach(Account.Kind.allCases){kind in
                    Text(kind.rawValue)
                    //labelName = kind.rawValue
                   
                }
                
            } .pickerStyle(WheelPickerStyle())
            
            
            
        }
        .navigationBarTitle("Add account")
        .toolbar{
            ToolbarItem(placement: .navigationBarTrailing) {
                Button{
                    //REMEMBER TO INSERT IF LET
                    appstateController.addAccount(name: name, iban: iban, kind: selectedKind)
                    dismiss()
                    
                } label: {
                    Text("Add")
                }
            }
        }
    }
    

    
}

/*
struct AddAccount_Previews: PreviewProvider {
    static var previews: some View {
        AddAccount()
    }
}
*/


