//
//  MakeTransaction.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import SwiftUI

struct MakeTransaction: View {
    
    @Environment(\.dismiss) var dismiss
    
    @EnvironmentObject var appstateController: AppstateController
    
    var account: Account //Model reference
    
    @State private var amount = 0.00
    @State private var beneficiary = ""
    @State private var isWithdrawal = false //Fortæller om man hæver eller sætter penge ind
    @State private var alertPresent = false //Til
    @State private var selectedAction = 0 //Hjælpevariabel til at løbe igennem nedenstående array
    var actions = ["Withdrawal", "Deposit"] //Til at beslutte om man vil hæve eller indsætte
    
    var body: some View {
        Form {
            Section(header:Text("New transaction")){
                    TextField("Beneficiary", text: $beneficiary)
                    .keyboardType(.alphabet)
                        
                    TextField("Selected amount", value: $amount, formatter: NumberFormatter())
                    .keyboardType(.decimalPad) //Det lykkedes mig ikke at begrænse det til kun at tage tal som input
                
                 //Gør så man kan vælge mellem to værdier ved at løbe arrayet action igenem via selectedaction som holder indexet for nuværende valg
                Picker("Type", selection: $selectedAction){
                    ForEach(0 ..< actions.count){
                        Text(self.actions[$0]).tag($0)
                    }
                }.pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle("New Transaction")
        .toolbar{
            ToolbarItem(placement: .navigationBarTrailing) {
                Button{
                    //Switcher på hjælpevariablen for at beslutte om man skal hæve penge eller ikke
                    switch selectedAction{
                    case 0:
                        isWithdrawal = true
                    case 1:
                        isWithdrawal = false
                    default:
                        isWithdrawal = false
                    }
                    
                    //Hvis beløbet man vil hæve er større end sin saldo
                    if(isWithdrawal && amount > account.balance){
                        alertPresent = true
                    }
                    
                    
                    if(!alertPresent){
                        let transaction: Transaction = Transaction(transactionAmount: amount, date: Date(), beneficiary: beneficiary, isWithdrawal: isWithdrawal)
                        appstateController.addTransaction(account: account, transaction: transaction)
                        dismiss()
                    }
                                                        
                    
                    
                } label: {
                    Text("Complete transaction")
                } .alert(isPresented: $alertPresent) {
                    Alert(
                        title: Text("Not enough funds"),
                        message: Text("Amount to withdraw is greater than your current balance ")
                    
                    )
                }
                        
        }
       }
    }
    
}

/*
struct MakeTransaction_Previews: PreviewProvider {
    static var previews: some View {
        MakeTransaction(account: account())
    }
}
 */
