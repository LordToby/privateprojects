//
//  Transaction.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import Foundation


struct Transaction: Identifiable, Codable{
    var id = UUID().uuidString
    let transactionAmount: Double //Måske splitte op i to?
    let date: Date
    let beneficiary: String
    let isWithdrawal: Bool
    
}


