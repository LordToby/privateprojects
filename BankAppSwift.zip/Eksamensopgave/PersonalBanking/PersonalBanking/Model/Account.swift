//
//  Account.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import Foundation
import FirebaseFirestoreSwift



struct Account: Codable,Identifiable{
    @DocumentID var id: String?
    let name: String
    let iban: String
    let kind: Kind
    private (set) var transactions: [Transaction] //Det er et set så vi undgår dupletter
        
    //Computed property. Er transaktionet et hævet beløb trækkes pengene fra. Er det en indsættelse, så er lægges pengene til saldoen.
    var balance: Double {
        var balance = 0.0 //localbalance
        for transaction in transactions {
            if(!transaction.isWithdrawal){
                balance += transaction.transactionAmount
            }
            else{
                balance -= transaction.transactionAmount
            }
          
        }
        return balance
      }

   
    
    init(name: String, iban: String, kind: Kind){
        self.name = name
        self.iban = iban
        self.kind = kind
        transactions = [ Transaction(
             transactionAmount: 200, date: Date(), beneficiary: "initialBalance", isWithdrawal: false
            )]

          }
    
    
    mutating func add(_ transaction: Transaction) {
        transactions.append(transaction)
      }
}


extension Account{
    enum Kind:String, Codable, CaseIterable, Identifiable{
        case checking = "checkings"
        case savings = "savings"
        case investment = "investment"
        case leisure = "leisure"
        var id: Self {self}
    }
}

