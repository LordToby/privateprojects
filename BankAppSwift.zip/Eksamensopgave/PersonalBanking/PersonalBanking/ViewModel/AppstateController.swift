//
//  AppstateController.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import Foundation

//ViewModel
class AppstateController: ObservableObject{
    
    
    private let db = FirebaseService()
    
    @Published var accounts = [Account]() //Single source of truth
    
    
    init(){
         
        db.listen { querySnapshot in
            print("Så er vi inde i listen")
            self.accounts.removeAll() //Tømmer listen før vi kan putte accounts ind i den
            querySnapshot.documents.forEach {
                document in
//                //Konverterer det rå data til en user
                do{
                    let account = try document.data(as: Account.self)
                    self.accounts.append(account)
                }
                catch{
                    print("Der skete en konverteringsfejl")
                }
            }

        }
    }
    
    //ID kommer automatisk med
    func addAccount(name: String, iban: String, kind: Account.Kind){
        db.add(account: Account(name: name, iban: iban, kind: kind))
    }
        
    func addTransaction(account: Account, transaction: Transaction){
         //accounts[index].add(transaction)
        let index = accounts.firstIndex{$0.id == account.id}
        if let index = index, let documentID = accounts[index].id{
            accounts[index].add(transaction)
            db.updateAccount(account: accounts[index])
        }
    }

}

