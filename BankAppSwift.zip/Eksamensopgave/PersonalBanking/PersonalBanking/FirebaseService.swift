//
//  FirebaseService.swift
//  PersonalBanking
//
//  Created by Tobias on 05/05/2022.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class FirebaseService{
    
    //Reference til Firebase
    private let dbRef = Firestore.firestore() //reference til hele databasen

    
    //Tilføjer dokument til databasen
    func add(account: Account){

        let ref = dbRef.collection("accounts")
        do{
            let newDocReference = try ref.addDocument(from: account.self)
            print("Account added with new reference: \(newDocReference)")
        }
        catch{
            print("Det lykkedes ikke")
        }
        
    }

    //Henter alle dokumenter fra listen
    func listen(completionHandler: @escaping (QuerySnapshot)->Void){
        let listener = dbRef.collection("accounts").addSnapshotListener{
            querySnapshot, error in
            //Unwrapper en optional
            guard let querySnapshot = querySnapshot else{
                print("ERROR: kunne ikke hente data: \(String(describing: error))")
                return
            }
            completionHandler(querySnapshot)
        }

    }
        
    //Opdaterer en konto i databasen med den tilføjede transaktion
    func updateAccount(account: Account){
        
        if let documentId = account.id{
            do{
                try dbRef.collection("accounts").document(documentId).setData(from: account)
            }
            catch {
                print("Failure")
            }
        }
        
      
    }
    
}


